-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 24 Jun 2024 pada 09.22
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_smartpark`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `approvals`
--

CREATE TABLE `approvals` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `vehicle_id` bigint(20) UNSIGNED NOT NULL,
  `block_id` bigint(20) UNSIGNED NOT NULL,
  `entry_time` timestamp NULL DEFAULT NULL,
  `exit_time` timestamp NULL DEFAULT NULL,
  `action` enum('Entry','Exit','Pending') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `approvals`
--

INSERT INTO `approvals` (`id`, `vehicle_id`, `block_id`, `entry_time`, `exit_time`, `action`, `created_at`, `updated_at`) VALUES
(2, 2, 1, '2024-06-06 07:28:15', '2024-06-06 07:28:38', 'Exit', '2024-06-06 07:28:15', '2024-06-06 07:30:04'),
(3, 1, 1, '2024-06-06 07:28:21', '2024-06-06 07:28:32', 'Exit', '2024-06-06 07:28:21', '2024-06-06 07:30:56'),
(4, 2, 1, '2024-06-09 08:11:49', '2024-06-09 08:11:54', 'Exit', '2024-06-09 08:11:49', '2024-06-09 08:49:59'),
(7, 2, 1, '2024-06-14 08:37:16', '2024-06-14 08:37:19', 'Exit', '2024-06-14 08:37:16', '2024-06-14 08:38:37'),
(8, 2, 1, '2024-06-14 18:34:37', '2024-06-14 18:35:13', 'Exit', '2024-06-14 18:34:37', '2024-06-14 18:37:06'),
(9, 2, 1, '2024-06-14 18:37:55', '2024-06-14 18:38:00', 'Exit', '2024-06-14 18:37:55', '2024-06-14 18:45:42'),
(10, 3, 1, '2024-06-21 18:48:57', '2024-06-21 18:49:02', 'Exit', '2024-06-21 18:48:57', '2024-06-21 18:49:59'),
(11, 3, 1, '2024-06-21 18:50:32', '2024-06-21 18:50:35', 'Exit', '2024-06-21 18:50:32', '2024-06-21 18:51:29'),
(12, 2, 2, '2024-06-21 19:05:59', '2024-06-21 19:06:05', 'Exit', '2024-06-21 19:05:59', '2024-06-21 19:06:56'),
(13, 2, 1, '2024-06-21 19:07:43', '2024-06-21 19:08:10', 'Exit', '2024-06-21 19:07:43', '2024-06-21 19:08:59'),
(14, 4, 1, '2024-06-21 19:14:26', '2024-06-21 19:14:46', 'Exit', '2024-06-21 19:14:26', '2024-06-21 19:16:21'),
(16, 2, 1, '2024-06-22 00:39:24', '2024-06-22 00:39:45', 'Exit', '2024-06-22 00:39:24', '2024-06-22 00:45:57'),
(17, 2, 1, '2024-06-22 08:00:40', '2024-06-22 08:00:58', 'Exit', '2024-06-22 08:00:40', '2024-06-22 08:01:15');

-- --------------------------------------------------------

--
-- Struktur dari tabel `block_numbers`
--

CREATE TABLE `block_numbers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `floor_id` bigint(20) UNSIGNED NOT NULL,
  `block` varchar(255) NOT NULL,
  `is_occupied` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `block_numbers`
--

INSERT INTO `block_numbers` (`id`, `floor_id`, `block`, `is_occupied`, `created_at`, `updated_at`) VALUES
(1, 1, 'Blok A', 0, '2024-06-06 07:06:15', '2024-06-22 08:01:15'),
(2, 1, 'Blok B', 0, '2024-06-06 07:06:15', '2024-06-21 19:06:56'),
(3, 1, 'Blok C', 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15'),
(4, 1, 'Blok D', 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15'),
(5, 1, 'Blok E', 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15'),
(6, 2, 'Blok A', 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15'),
(7, 2, 'Blok B', 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15'),
(8, 2, 'Blok C', 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15'),
(9, 2, 'Blok D', 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15'),
(10, 2, 'Blok E', 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15'),
(11, 3, 'Blok A', 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15'),
(12, 3, 'Blok B', 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15'),
(13, 3, 'Blok C', 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15'),
(14, 3, 'Blok D', 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15'),
(15, 3, 'Blok E', 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15'),
(16, 4, 'Blok A', 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15'),
(17, 4, 'Blok B', 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15'),
(18, 4, 'Blok C', 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15'),
(19, 4, 'Blok D', 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15'),
(20, 4, 'Blok E', 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15'),
(21, 5, 'Blok A', 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15'),
(22, 5, 'Blok B', 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15'),
(23, 5, 'Blok C', 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15'),
(24, 5, 'Blok D', 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15'),
(25, 5, 'Blok E', 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15');

-- --------------------------------------------------------

--
-- Struktur dari tabel `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000001_create_cache_table', 1),
(2, '0001_01_01_000002_create_jobs_table', 1),
(3, '2024_05_15_160515_create_users_table', 1),
(4, '2024_05_15_160624_create_vehicle_types_table', 1),
(5, '2024_05_15_160625_create_vehicles_table', 1),
(6, '2024_05_15_160935_create_parking_floors_table', 1),
(7, '2024_05_15_160957_create_block_numbers_table', 1),
(8, '2024_05_15_161013_create_parking_sessions_table', 1),
(9, '2024_05_15_161014_create_payments_table', 1),
(10, '2024_05_16_154935_create_approvals_table', 1),
(11, '2024_05_30_183409_create_notifications_table', 1),
(12, '2024_06_06_095429_create_personal_access_tokens_table', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `notifications`
--

CREATE TABLE `notifications` (
  `id` char(36) NOT NULL,
  `type` varchar(255) NOT NULL,
  `notifiable_type` varchar(255) NOT NULL,
  `notifiable_id` bigint(20) UNSIGNED NOT NULL,
  `data` text NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `notifications`
--

INSERT INTO `notifications` (`id`, `type`, `notifiable_type`, `notifiable_id`, `data`, `read_at`, `created_at`, `updated_at`) VALUES
('0a929f62-6a6b-4926-96eb-e5b11bf7072d', 'App\\Notifications\\ParkingApprovalNotification', 'App\\Models\\User', 4, '{\"message\":\"Permintaan keluar parkir Anda telah Approved.\",\"status\":\"Approved\"}', '2024-06-21 19:07:03', '2024-06-21 19:06:56', '2024-06-21 19:07:03'),
('35a95c64-6eb5-4a25-afbe-8733bd2ae8d7', 'App\\Notifications\\ParkingApprovalNotification', 'App\\Models\\User', 4, '{\"message\":\"Permintaan keluar parkir Anda telah Approved.\",\"status\":\"Approved\"}', '2024-06-14 08:35:02', '2024-06-14 08:34:26', '2024-06-14 08:35:02'),
('48b018ef-c78d-4bc8-8e97-82fab2c78fdb', 'App\\Notifications\\ParkingApprovalNotification', 'App\\Models\\User', 4, '{\"message\":\"Permintaan keluar parkir Anda telah Approved.\",\"status\":\"Approved\"}', '2024-06-09 08:50:04', '2024-06-09 08:49:59', '2024-06-09 08:50:04'),
('4b71d850-20f8-4327-8938-e0b873111c2f', 'App\\Notifications\\ParkingApprovalNotification', 'App\\Models\\User', 4, '{\"message\":\"Permintaan keluar parkir Anda telah Approved.\",\"status\":\"Approved\"}', '2024-06-21 19:09:05', '2024-06-21 19:08:59', '2024-06-21 19:09:05'),
('4e2eb995-4365-48ec-a533-cdc63d8fe883', 'App\\Notifications\\ParkingApprovalNotification', 'App\\Models\\User', 7, '{\"message\":\"Permintaan keluar parkir Anda telah Approved.\",\"status\":\"Approved\"}', '2024-06-21 19:16:29', '2024-06-21 19:16:21', '2024-06-21 19:16:29'),
('534acb58-e3fb-4d43-bd90-6ff12d45e9aa', 'App\\Notifications\\ParkingApprovalNotification', 'App\\Models\\User', 4, '{\"message\":\"Permintaan keluar parkir Anda telah Approved.\",\"status\":\"Approved\"}', '2024-06-06 09:26:58', '2024-06-06 07:30:04', '2024-06-06 09:26:58'),
('57d20974-ab94-46fc-b22a-25e7313af53f', 'App\\Notifications\\ParkingApprovalNotification', 'App\\Models\\User', 4, '{\"message\":\"Permintaan keluar parkir Anda telah Approved.\",\"status\":\"Approved\"}', '2024-06-14 08:38:45', '2024-06-14 08:38:37', '2024-06-14 08:38:45'),
('6753ae48-1f50-4858-a514-fd721eb6a27c', 'App\\Notifications\\ParkingApprovalNotification', 'App\\Models\\User', 4, '{\"message\":\"Permintaan keluar parkir Anda telah Approved.\",\"status\":\"Approved\"}', '2024-06-22 08:01:41', '2024-06-22 08:01:15', '2024-06-22 08:01:41'),
('7084b626-eef6-4ab0-b1ac-7e0d4868caed', 'App\\Notifications\\ParkingApprovalNotification', 'App\\Models\\User', 3, '{\"message\":\"Permintaan keluar parkir Anda telah Approved.\",\"status\":\"Approved\"}', '2024-06-06 07:27:02', '2024-06-06 07:26:50', '2024-06-06 07:27:02'),
('73d89b9b-f6d4-4293-b428-0a0ec534163d', 'App\\Notifications\\ParkingApprovalNotification', 'App\\Models\\User', 4, '{\"message\":\"Permintaan keluar parkir Anda telah Approved.\",\"status\":\"Approved\"}', '2024-06-22 00:46:10', '2024-06-22 00:45:57', '2024-06-22 00:46:10'),
('7a26a4f8-d333-4d92-9ed0-c32d88826384', 'App\\Notifications\\ParkingApprovalNotification', 'App\\Models\\User', 4, '{\"message\":\"Permintaan keluar parkir Anda telah Approved.\",\"status\":\"Approved\"}', '2024-06-14 18:37:11', '2024-06-14 18:37:06', '2024-06-14 18:37:11'),
('a0b63447-910c-428c-b455-3c7747be1a3d', 'App\\Notifications\\ParkingApprovalNotification', 'App\\Models\\User', 4, '{\"message\":\"Permintaan keluar parkir Anda telah Rejected.\",\"status\":\"Rejected\"}', '2024-06-14 08:34:03', '2024-06-14 08:33:58', '2024-06-14 08:34:03'),
('b79d4d53-ab68-49ee-a3ed-c426b11d150f', 'App\\Notifications\\ParkingApprovalNotification', 'App\\Models\\User', 6, '{\"message\":\"Permintaan keluar parkir Anda telah Approved.\",\"status\":\"Approved\"}', '2024-06-21 18:50:11', '2024-06-21 18:49:59', '2024-06-21 18:50:11'),
('bc68be30-28f2-430a-bd81-ca60a8a699c5', 'App\\Notifications\\ParkingApprovalNotification', 'App\\Models\\User', 6, '{\"message\":\"Permintaan keluar parkir Anda telah Approved.\",\"status\":\"Approved\"}', '2024-06-21 18:51:35', '2024-06-21 18:51:29', '2024-06-21 18:51:35'),
('e1cf0b5a-8288-4700-b6e2-e27687caa930', 'App\\Notifications\\ParkingApprovalNotification', 'App\\Models\\User', 4, '{\"message\":\"Permintaan keluar parkir Anda telah Approved.\",\"status\":\"Approved\"}', '2024-06-14 18:45:47', '2024-06-14 18:45:42', '2024-06-14 18:45:47'),
('e9ba9c56-78be-4ab4-962b-e2d2449903d9', 'App\\Notifications\\ParkingApprovalNotification', 'App\\Models\\User', 4, '{\"message\":\"Permintaan keluar parkir Anda telah Rejected.\",\"status\":\"Rejected\"}', '2024-06-14 18:44:52', '2024-06-14 18:44:48', '2024-06-14 18:44:52'),
('ecabdd10-49f2-49af-aa48-e7a4ba2db43a', 'App\\Notifications\\ParkingApprovalNotification', 'App\\Models\\User', 3, '{\"message\":\"Permintaan keluar parkir Anda telah Approved.\",\"status\":\"Approved\"}', '2024-06-06 09:27:13', '2024-06-06 07:30:56', '2024-06-06 09:27:13'),
('f3ee81a7-1642-4dca-b7fe-a257b1797036', 'App\\Notifications\\ParkingApprovalNotification', 'App\\Models\\User', 4, '{\"message\":\"Permintaan keluar parkir Anda telah Rejected.\",\"status\":\"Rejected\"}', '2024-06-14 18:38:31', '2024-06-14 18:38:25', '2024-06-14 18:38:31');

-- --------------------------------------------------------

--
-- Struktur dari tabel `parking_floors`
--

CREATE TABLE `parking_floors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `floor_number` int(11) NOT NULL,
  `capacity` int(11) NOT NULL,
  `occupied_spots` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `parking_floors`
--

INSERT INTO `parking_floors` (`id`, `floor_number`, `capacity`, `occupied_spots`, `created_at`, `updated_at`) VALUES
(1, 1, 50, 0, '2024-06-06 07:06:15', '2024-06-22 08:00:58'),
(2, 2, 50, 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15'),
(3, 3, 50, 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15'),
(4, 4, 50, 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15'),
(5, 5, 50, 0, '2024-06-06 07:06:15', '2024-06-06 07:06:15');

-- --------------------------------------------------------

--
-- Struktur dari tabel `parking_sessions`
--

CREATE TABLE `parking_sessions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `vehicle_id` bigint(20) UNSIGNED NOT NULL,
  `spot_id` bigint(20) UNSIGNED NOT NULL,
  `approval_status` enum('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `parking_sessions`
--

INSERT INTO `parking_sessions` (`id`, `user_id`, `vehicle_id`, `spot_id`, `approval_status`, `created_at`, `updated_at`) VALUES
(2, 3, 1, 1, 'Approved', '2024-06-06 07:28:32', '2024-06-06 07:30:56'),
(3, 4, 2, 1, 'Approved', '2024-06-06 07:28:38', '2024-06-06 07:30:04'),
(4, 4, 2, 1, 'Approved', '2024-06-09 08:11:53', '2024-06-09 08:49:59'),
(7, 4, 2, 1, 'Approved', '2024-06-14 08:37:19', '2024-06-14 08:38:37'),
(8, 4, 2, 1, 'Approved', '2024-06-14 18:35:13', '2024-06-14 18:37:06'),
(9, 4, 2, 1, 'Approved', '2024-06-14 18:38:00', '2024-06-14 18:45:42'),
(10, 6, 3, 1, 'Approved', '2024-06-21 18:49:02', '2024-06-21 18:49:59'),
(11, 6, 3, 1, 'Approved', '2024-06-21 18:50:35', '2024-06-21 18:51:29'),
(12, 4, 2, 2, 'Approved', '2024-06-21 19:06:05', '2024-06-21 19:06:56'),
(13, 4, 2, 1, 'Approved', '2024-06-21 19:08:09', '2024-06-21 19:08:59'),
(14, 7, 4, 1, 'Approved', '2024-06-21 19:14:45', '2024-06-21 19:16:21'),
(16, 4, 2, 1, 'Approved', '2024-06-22 00:39:45', '2024-06-22 00:45:57'),
(17, 4, 2, 1, 'Approved', '2024-06-22 08:00:57', '2024-06-22 08:01:15');

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `payments`
--

CREATE TABLE `payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `session_id` bigint(20) UNSIGNED NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_status` enum('Paid','Pending','Failed') NOT NULL DEFAULT 'Pending',
  `payment_method` varchar(50) NOT NULL,
  `transaction_id` varchar(100) NOT NULL,
  `snap_token` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `payments`
--

INSERT INTO `payments` (`id`, `session_id`, `amount`, `payment_status`, `payment_method`, `transaction_id`, `snap_token`, `created_at`, `updated_at`) VALUES
(2, 2, '3000.00', 'Paid', 'Midtrans', '3-1717684112', '820583d5-62df-4213-8849-3cf54173db23', '2024-06-06 07:28:32', '2024-06-06 07:30:27'),
(3, 3, '5000.00', 'Paid', 'Midtrans', '2-1717684118', '28917b2d-6549-4ed4-9e79-f31aa610b8a1', '2024-06-06 07:28:38', '2024-06-06 07:29:28'),
(4, 4, '5000.00', 'Paid', 'Midtrans', '4-1717945913', '0c7a9cba-7c47-4b91-9308-70a818fe2f4d', '2024-06-09 08:11:53', '2024-06-09 08:48:53'),
(7, 7, '5000.00', 'Paid', 'Midtrans', '7-1718379439', 'fe242ed0-a144-4cea-8a24-6bf22826dc30', '2024-06-14 08:37:19', '2024-06-14 08:37:36'),
(8, 8, '5000.00', 'Paid', 'Midtrans', '8-1718415313', '81acc91f-6b0b-43a9-a786-29abd1866fc6', '2024-06-14 18:35:13', '2024-06-14 18:36:17'),
(9, 9, '5000.00', 'Paid', 'Midtrans', '9-1718415480', 'a440747c-d3ed-44e1-abbf-23eb26918d9c', '2024-06-14 18:38:00', '2024-06-14 18:45:12'),
(10, 10, '3000.00', 'Paid', 'Midtrans', '10-1719020942', 'dde2cf66-ea05-425e-8c85-a970af86ea69', '2024-06-21 18:49:02', '2024-06-21 18:49:21'),
(11, 11, '3000.00', 'Paid', 'Midtrans', '11-1719021035', 'd7e69043-572a-42b7-9fb6-ae7307b9adf9', '2024-06-21 18:50:35', '2024-06-21 18:50:51'),
(12, 12, '5000.00', 'Paid', 'Midtrans', '12-1719021965', 'd749ad42-5530-403c-bc67-29760e60156d', '2024-06-21 19:06:05', '2024-06-21 19:06:19'),
(13, 13, '5000.00', 'Paid', 'Midtrans', '13-1719022089', '8f4cca1f-b769-4921-a688-8a36782e0d0d', '2024-06-21 19:08:09', '2024-06-21 19:08:24'),
(14, 14, '3000.00', 'Paid', 'Midtrans', '14-1719022485', '9dc1943a-9f31-4eb9-bcbf-d779def7fcb8', '2024-06-21 19:14:45', '2024-06-21 19:15:26'),
(16, 16, '5000.00', 'Pending', 'Midtrans', '16-1719041985', 'b53f4c20-153a-4efe-9bc7-2019554e6127', '2024-06-22 00:39:45', '2024-06-22 00:39:45'),
(17, 17, '5000.00', 'Pending', 'Midtrans', '17-1719043257', '04a5ad98-20be-461a-a9c7-1fe738a19229', '2024-06-22 08:00:57', '2024-06-22 08:00:58');

-- --------------------------------------------------------

--
-- Struktur dari tabel `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('bGwT7avv8YjXWgmqJ0Rtp8waMCdhJJ6fNuavDvlX', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiYzlzWm5lSmZqbldnU0xXeHZEYzN5cWoxdVVZNUxOV1NIbnlxVTNUQiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJuZXciO2E6MDp7fXM6Mzoib2xkIjthOjMwOntpOjA7czoxODoiYWxlcnQuY29uZmlnLnRpdGxlIjtpOjE7czoxNzoiYWxlcnQuY29uZmlnLnRleHQiO2k6MjtzOjE4OiJhbGVydC5jb25maWcudGltZXIiO2k6MztzOjIzOiJhbGVydC5jb25maWcuYmFja2dyb3VuZCI7aTo0O3M6MTg6ImFsZXJ0LmNvbmZpZy53aWR0aCI7aTo1O3M6MjM6ImFsZXJ0LmNvbmZpZy5oZWlnaHRBdXRvIjtpOjY7czoyMDoiYWxlcnQuY29uZmlnLnBhZGRpbmciO2k6NztzOjMwOiJhbGVydC5jb25maWcuc2hvd0NvbmZpcm1CdXR0b24iO2k6ODtzOjI4OiJhbGVydC5jb25maWcuc2hvd0Nsb3NlQnV0dG9uIjtpOjk7czozMDoiYWxlcnQuY29uZmlnLmNvbmZpcm1CdXR0b25UZXh0IjtpOjEwO3M6Mjk6ImFsZXJ0LmNvbmZpZy5jYW5jZWxCdXR0b25UZXh0IjtpOjExO3M6Mjk6ImFsZXJ0LmNvbmZpZy50aW1lclByb2dyZXNzQmFyIjtpOjEyO3M6MjQ6ImFsZXJ0LmNvbmZpZy5jdXN0b21DbGFzcyI7aToxMztzOjE3OiJhbGVydC5jb25maWcuaWNvbiI7aToxNDtzOjEyOiJhbGVydC5jb25maWciO2k6MTU7czoxODoiYWxlcnQuY29uZmlnLnRpdGxlIjtpOjE2O3M6MTc6ImFsZXJ0LmNvbmZpZy50ZXh0IjtpOjE3O3M6MTg6ImFsZXJ0LmNvbmZpZy50aW1lciI7aToxODtzOjIzOiJhbGVydC5jb25maWcuYmFja2dyb3VuZCI7aToxOTtzOjE4OiJhbGVydC5jb25maWcud2lkdGgiO2k6MjA7czoyMzoiYWxlcnQuY29uZmlnLmhlaWdodEF1dG8iO2k6MjE7czoyMDoiYWxlcnQuY29uZmlnLnBhZGRpbmciO2k6MjI7czozMDoiYWxlcnQuY29uZmlnLnNob3dDb25maXJtQnV0dG9uIjtpOjIzO3M6Mjg6ImFsZXJ0LmNvbmZpZy5zaG93Q2xvc2VCdXR0b24iO2k6MjQ7czozMDoiYWxlcnQuY29uZmlnLmNvbmZpcm1CdXR0b25UZXh0IjtpOjI1O3M6Mjk6ImFsZXJ0LmNvbmZpZy5jYW5jZWxCdXR0b25UZXh0IjtpOjI2O3M6Mjk6ImFsZXJ0LmNvbmZpZy50aW1lclByb2dyZXNzQmFyIjtpOjI3O3M6MjQ6ImFsZXJ0LmNvbmZpZy5jdXN0b21DbGFzcyI7aToyODtzOjE3OiJhbGVydC5jb25maWcuaWNvbiI7aToyOTtzOjEyOiJhbGVydC5jb25maWciO319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9sb2dpbiI7fXM6NToiYWxlcnQiO2E6MDp7fX0=', 1719043304),
('lc9N1mVDvQGLs2qGE0HZ3YYFyGbSoLnSGjg4I9LB', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiN1BwSUU1UnZBbDkzRTVtUVRITDBPRDdRMUV2ZEV5c05uSnhhSnM1ZyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJuZXciO2E6MDp7fXM6Mzoib2xkIjthOjMwOntpOjA7czoxODoiYWxlcnQuY29uZmlnLnRpdGxlIjtpOjE7czoxNzoiYWxlcnQuY29uZmlnLnRleHQiO2k6MjtzOjE4OiJhbGVydC5jb25maWcudGltZXIiO2k6MztzOjIzOiJhbGVydC5jb25maWcuYmFja2dyb3VuZCI7aTo0O3M6MTg6ImFsZXJ0LmNvbmZpZy53aWR0aCI7aTo1O3M6MjM6ImFsZXJ0LmNvbmZpZy5oZWlnaHRBdXRvIjtpOjY7czoyMDoiYWxlcnQuY29uZmlnLnBhZGRpbmciO2k6NztzOjMwOiJhbGVydC5jb25maWcuc2hvd0NvbmZpcm1CdXR0b24iO2k6ODtzOjI4OiJhbGVydC5jb25maWcuc2hvd0Nsb3NlQnV0dG9uIjtpOjk7czozMDoiYWxlcnQuY29uZmlnLmNvbmZpcm1CdXR0b25UZXh0IjtpOjEwO3M6Mjk6ImFsZXJ0LmNvbmZpZy5jYW5jZWxCdXR0b25UZXh0IjtpOjExO3M6Mjk6ImFsZXJ0LmNvbmZpZy50aW1lclByb2dyZXNzQmFyIjtpOjEyO3M6MjQ6ImFsZXJ0LmNvbmZpZy5jdXN0b21DbGFzcyI7aToxMztzOjE3OiJhbGVydC5jb25maWcuaWNvbiI7aToxNDtzOjEyOiJhbGVydC5jb25maWciO2k6MTU7czoxODoiYWxlcnQuY29uZmlnLnRpdGxlIjtpOjE2O3M6MTc6ImFsZXJ0LmNvbmZpZy50ZXh0IjtpOjE3O3M6MTg6ImFsZXJ0LmNvbmZpZy50aW1lciI7aToxODtzOjIzOiJhbGVydC5jb25maWcuYmFja2dyb3VuZCI7aToxOTtzOjE4OiJhbGVydC5jb25maWcud2lkdGgiO2k6MjA7czoyMzoiYWxlcnQuY29uZmlnLmhlaWdodEF1dG8iO2k6MjE7czoyMDoiYWxlcnQuY29uZmlnLnBhZGRpbmciO2k6MjI7czozMDoiYWxlcnQuY29uZmlnLnNob3dDb25maXJtQnV0dG9uIjtpOjIzO3M6Mjg6ImFsZXJ0LmNvbmZpZy5zaG93Q2xvc2VCdXR0b24iO2k6MjQ7czozMDoiYWxlcnQuY29uZmlnLmNvbmZpcm1CdXR0b25UZXh0IjtpOjI1O3M6Mjk6ImFsZXJ0LmNvbmZpZy5jYW5jZWxCdXR0b25UZXh0IjtpOjI2O3M6Mjk6ImFsZXJ0LmNvbmZpZy50aW1lclByb2dyZXNzQmFyIjtpOjI3O3M6MjQ6ImFsZXJ0LmNvbmZpZy5jdXN0b21DbGFzcyI7aToyODtzOjE3OiJhbGVydC5jb25maWcuaWNvbiI7aToyOTtzOjEyOiJhbGVydC5jb25maWciO319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9sb2dpbiI7fXM6NToiYWxlcnQiO2E6MDp7fX0=', 1719043292);

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `jk` enum('L','P') NOT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `bio` varchar(255) DEFAULT NULL,
  `role` enum('admin','staff','pengunjung') NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `username`, `full_name`, `email`, `email_verified_at`, `password`, `jk`, `foto`, `bio`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admintest', 'admin@admin.com', '2024-06-06 07:06:08', '$2y$12$ucx17I/QiEuF6OIJjBT/seY7UKcPU3tloxD0q.76cscNhD/8GzfIi', 'L', NULL, NULL, 'admin', 'U0O6x5s4SjORqbECLHWOO2fTSIj207FCA5j7ZmmumayrzoRSJpNybfTafuri', '2024-06-06 07:06:09', '2024-06-06 07:06:09'),
(2, 'staff', 'stafftest', 'staff@staff.com', '2024-06-06 07:06:09', '$2y$12$hQG77LKkLJZfkXrkSADEV.5sAcxn4egIEBkKVYPy9cN6mN1TSZPuK', 'L', NULL, NULL, 'staff', 'mW2WU2tKvw', '2024-06-06 07:06:09', '2024-06-06 07:06:09'),
(3, 'pengunjung', 'pengunjungtest', 'pengunjung@pengunjung.com', '2024-06-06 07:06:09', '$2y$12$74AaR8qqNs/rm5jMCYsnfO.Lk/1R8xiM7ZukXStrhdqL/X/LztQKG', 'L', NULL, NULL, 'pengunjung', 'g0pI1YmZ0ow6ipcTSIHuXfJe5AT95fBScWzqUe6REyT1HX1QrIQ9aVvFRFFB', '2024-06-06 07:06:10', '2024-06-06 07:06:10'),
(4, 'pengunjung1', 'testtttt', 'p@mail.com', NULL, '$2y$12$c80dVItw7kWT4Age3mIl4OJEDgQkxAPmI.ZV/UDrzGiZ69VYHCZIG', 'L', NULL, NULL, 'pengunjung', NULL, '2024-06-06 07:19:05', '2024-06-06 07:19:05'),
(6, 'pengunjung3', 'test', 'pengunjung3@mail.com', NULL, '$2y$12$tIzNyg.IqhQtnFee/CLsXe07bygAnAsQiDwfmOzYmf5OqZylUg1pW', 'P', NULL, NULL, 'pengunjung', NULL, '2024-06-21 18:11:43', '2024-06-21 18:11:43'),
(7, 'pengunjung4', 'testtttt', 'pengunjung4@mail.com', NULL, '$2y$12$W8EOL8DUOO6ZIMIcvumgJuwhd8TwPmDBgYjHZp5HBBkqggJyBDTEW', 'L', NULL, NULL, 'pengunjung', NULL, '2024-06-21 19:13:13', '2024-06-21 19:13:13');

-- --------------------------------------------------------

--
-- Struktur dari tabel `vehicles`
--

CREATE TABLE `vehicles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `vehicle_type_id` bigint(20) UNSIGNED NOT NULL,
  `licence_plate` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `vehicles`
--

INSERT INTO `vehicles` (`id`, `user_id`, `vehicle_type_id`, `licence_plate`, `created_at`, `updated_at`) VALUES
(1, 3, 1, 'B41K', '2024-06-06 07:06:34', '2024-06-06 07:06:34'),
(2, 4, 2, 'B1JAK', '2024-06-06 07:28:09', '2024-06-06 07:28:09'),
(3, 6, 1, 'B1SA', '2024-06-21 18:46:55', '2024-06-21 18:46:55'),
(4, 7, 1, 'B8373TFV', '2024-06-21 19:13:57', '2024-06-21 19:13:57');

-- --------------------------------------------------------

--
-- Struktur dari tabel `vehicle_types`
--

CREATE TABLE `vehicle_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `vehicle_types`
--

INSERT INTO `vehicle_types` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Motor', '2024-06-06 07:06:10', '2024-06-06 07:06:10'),
(2, 'Mobil', '2024-06-06 07:06:10', '2024-06-06 07:06:10');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `approvals`
--
ALTER TABLE `approvals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `approvals_vehicle_id_foreign` (`vehicle_id`),
  ADD KEY `approvals_block_id_foreign` (`block_id`);

--
-- Indeks untuk tabel `block_numbers`
--
ALTER TABLE `block_numbers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `block_numbers_floor_id_foreign` (`floor_id`);

--
-- Indeks untuk tabel `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indeks untuk tabel `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indeks untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indeks untuk tabel `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indeks untuk tabel `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`);

--
-- Indeks untuk tabel `parking_floors`
--
ALTER TABLE `parking_floors`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `parking_sessions`
--
ALTER TABLE `parking_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parking_sessions_user_id_foreign` (`user_id`),
  ADD KEY `parking_sessions_vehicle_id_foreign` (`vehicle_id`),
  ADD KEY `parking_sessions_spot_id_foreign` (`spot_id`);

--
-- Indeks untuk tabel `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indeks untuk tabel `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `payments_session_id_foreign` (`session_id`);

--
-- Indeks untuk tabel `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indeks untuk tabel `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indeks untuk tabel `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `vehicles_licence_plate_unique` (`licence_plate`),
  ADD KEY `vehicles_user_id_foreign` (`user_id`),
  ADD KEY `vehicles_vehicle_type_id_foreign` (`vehicle_type_id`);

--
-- Indeks untuk tabel `vehicle_types`
--
ALTER TABLE `vehicle_types`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `approvals`
--
ALTER TABLE `approvals`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `block_numbers`
--
ALTER TABLE `block_numbers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `parking_floors`
--
ALTER TABLE `parking_floors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `parking_sessions`
--
ALTER TABLE `parking_sessions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `payments`
--
ALTER TABLE `payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `vehicle_types`
--
ALTER TABLE `vehicle_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `approvals`
--
ALTER TABLE `approvals`
  ADD CONSTRAINT `approvals_block_id_foreign` FOREIGN KEY (`block_id`) REFERENCES `block_numbers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `approvals_vehicle_id_foreign` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `block_numbers`
--
ALTER TABLE `block_numbers`
  ADD CONSTRAINT `block_numbers_floor_id_foreign` FOREIGN KEY (`floor_id`) REFERENCES `parking_floors` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `parking_sessions`
--
ALTER TABLE `parking_sessions`
  ADD CONSTRAINT `parking_sessions_spot_id_foreign` FOREIGN KEY (`spot_id`) REFERENCES `block_numbers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `parking_sessions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `parking_sessions_vehicle_id_foreign` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `parking_sessions` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `vehicles`
--
ALTER TABLE `vehicles`
  ADD CONSTRAINT `vehicles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vehicles_vehicle_type_id_foreign` FOREIGN KEY (`vehicle_type_id`) REFERENCES `vehicle_types` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
