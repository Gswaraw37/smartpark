@include('pengunjung.layouts.header')
@include('pengunjung.layouts.slider')

@yield('content')

@include('pengunjung.layouts.footer')