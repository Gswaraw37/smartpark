@include('auth.layouts.header')

<div class="container">

@yield('content')

</div>

@include('auth.layouts.script')