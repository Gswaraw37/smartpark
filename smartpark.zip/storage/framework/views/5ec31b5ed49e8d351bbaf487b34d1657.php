<?php $__env->startSection('content'); ?>
        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Pegawai</h1>

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <div class="row justify-content-between">
                    <div class="col-4">
                        <h6 class="m-0 font-weight-bold text-primary">Daftar Pegawai</h6>
                    </div>
                    <?php if(Auth::user()->role == 'admin'): ?>
                        <div class="col-4">
                            <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                + Tambah
                            </button>
                        </div>
                    <?php endif; ?>
                  </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Name</th>
                                <th>Position</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>No</th>
                                <th>Name</th>
                                <th>Position</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($s->username); ?></td>
                                    <td><?php echo e($s->role); ?></td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                                            <a href="<?php echo e(url('/admin/daftar-staff/' . $s->id)); ?>" class="btn btn-sm btn-success mr-1"><i class="fa-solid fa-eye"></i></a>
                                            <?php if(Auth::user()->role == 'admin'): ?>
                                                <form action="<?php echo e(url('/admin/daftar-staff/' . $s->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#confirmHapusModal">Delete</button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
  
  <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Tambah Pegawai</h5>
        </div>
        <div class="modal-body">
            <form abframeid="iframe.0.621681743693705" abineguid="6CBCF04EEF434DF783A5C40E835D891D" action="<?php echo e(url('/admin/daftar-staff/store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                    <label for="username" class="col-4 col-form-label">Username</label> 
                    <div class="col-8">
                    <input id="username" name="username" type="text" class="form-control" required>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="full_name" class="col-4 col-form-label">Full Name</label> 
                    <div class="col-8">
                    <input id="full_name" name="full_name" type="text" class="form-control" required>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="email" class="col-4 col-form-label">Email</label> 
                    <div class="col-8">
                    <input id="email" name="email" type="email" class="form-control" required>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="jk" class="col-4 col-form-label">Jenis Kelamin</label> 
                    <div class="col-8">
                        <?php $__currentLoopData = $gender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $cek = (old('g') == $g) ? 'checked' : '';
                        ?>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input name="jk" id="jk<?php echo e($g); ?>" type="radio" class="custom-control-input" value="<?php echo e($g); ?>" <?php echo e($cek); ?> required> 
                                <label for="jk<?php echo e($g); ?>" class="custom-control-label"><?php echo e($g); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="bio" class="col-4 col-form-label">Bio</label> 
                    <div class="col-8">
                    <textarea id="bio" name="bio" cols="40" rows="5" class="form-control"></textarea>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="role" class="col-4 col-form-label">Position</label> 
                    <div class="col-8">
                    <select id="role" name="role" class="custom-select" required>
                        <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($r); ?>"><?php echo e($r); ?></option> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="foto" class="col-4 col-form-label">Foto</label> 
                    <div class="col-8">
                        <input id="foto" name="foto" type="file" class="form-control">
                    </div>
                </div> 
                <div class="form-group row justify-content-center">
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                </div>
            </form>
        </div>
      </div>
    </div>
  </div>

  <div class="modal" id="confirmHapusModal">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body modal-bg1 text-center">
                <h5>Anda Yakin Ingin Menghapus Data Staff ini?</h5>
            </div>
            <div class="modalFooter text-center modal-bg1">
                <div class="mb-3">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="submit" class="btn btn-danger">Hapus</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\final-Project_Kelompok-1\resources\views/admin/daftar/staff/index.blade.php ENDPATH**/ ?>