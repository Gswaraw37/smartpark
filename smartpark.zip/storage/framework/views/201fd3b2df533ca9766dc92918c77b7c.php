<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\final-Project_Kelompok-1\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>