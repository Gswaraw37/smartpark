
<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<h1 align="center">Edit <?php echo e($staff->username); ?></h1>
<form abframeid="iframe.0.9274323699700593" abineguid="6CBCF04EEF434DF783A5C40E835D891D" action="/admin/daftar-staff/<?php echo e($staff->id); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="form-group row">
    <label for="username" class="col-4 col-form-label">Username</label> 
    <div class="col-8">
        <input id="username" name="username" type="text" class="form-control" value="<?php echo e($staff->username); ?>" readonly>
    </div>
    </div>
    <div class="form-group row">
    <label for="email" class="col-4 col-form-label">Email</label> 
    <div class="col-8">
        <input id="email" name="email" type="email" class="form-control" value="<?php echo e($staff->email); ?>" readonly>
    </div>
    </div>
    <div class="form-group row">
    <label for="password" class="col-4 col-form-label">Password</label> 
    <div class="col-8">
        <input id="password" name="password" type="password" class="form-control" placeholder="Masukan Password Baru">
    </div>
    </div>
    <div class="form-group row">
    <label for="full_name" class="col-4 col-form-label">Nama Lengkap</label> 
    <div class="col-8">
        <input id="full_name" name="full_name" type="text" class="form-control" value="<?php echo e($staff->full_name); ?>">
    </div>
    </div>
    <div class="form-group row">
    <label for="jk" class="col-4 col-form-label">Jenis Kelamin</label>
    <div class="col-8">
        <?php $__currentLoopData = $gender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $cek = ($g == $staff->jk) ? 'checked' : '';
        ?>
            <div class="custom-control custom-radio custom-control-inline">
                <input name="jk" id="jk<?php echo e($g); ?>" type="radio" class="custom-control-input" value="<?php echo e($g); ?>" <?php echo e($cek); ?>> 
                <label for="jk<?php echo e($g); ?>" class="custom-control-label"><?php echo e($g); ?></label>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>
    <div class="form-group row">
    <label for="bio" class="col-4 col-form-label">Bio</label> 
    <div class="col-8">
        <textarea id="bio" name="bio" cols="40" rows="5" class="form-control"><?php echo e($staff->bio); ?></textarea>
    </div>
    </div>
    <div class="form-group row">
        <label for="foto" class="col-4 col-form-label">Foto</label> 
        <div class="col-8">
            <?php if(!empty($staff->foto)): ?>
                <div class="mb-3">
                    <img id="preview" src="<?php echo e(asset('storage/' . $staff->foto)); ?>" alt="Product Image" class="img-fluid" style="max-width: 200px;">
                </div>
                <p>Current file: <?php echo e($staff->foto); ?></p>
            <?php else: ?>
                <div class="mb-3">
                    <img id="preview" src="<?php echo e(asset('storage/nophoto.jpg')); ?>" alt="Placeholder Image" class="img-fluid" style="max-width: 200px;">
                </div>
                <p>No file chosen</p>
            <?php endif; ?>
            <input id="foto" name="foto" type="file" class="form-control">
        </div>
    </div>
    <div class="form-group row">
    <div class="offset-4 col-8">
        <button name="submit" type="submit" class="btn btn-primary">Submit</button>
    </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\final-Project_Kelompok-1\resources\views/admin/daftar/staff/edit.blade.php ENDPATH**/ ?>