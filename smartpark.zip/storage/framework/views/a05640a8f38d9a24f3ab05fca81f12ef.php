<?php $__env->startSection('content'); ?>

    <?php if(Auth::user()->role == 'admin'): ?>
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Summary</h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="row justify-content-between">
                <div class="col-8">
                    <h6 class="m-0 font-weight-bold text-primary">Daftar Pengunjung</h6>
                </div>
                <div class="col-4">
                    <form action="<?php echo e(url('/admin/summary/export/excel')); ?>" method="GET">
                        <button type="submit" class="btn btn-primary font-weight-bold">Export Data</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Pengunjung</th>
                            <th>Jenis Kendaraan</th>
                            <th>Plat Nomor</th>
                            <th>Jam Masuk Parkir</th>
                            <th>Jam Keluar Parkir</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Nama Pengunjung</th>
                            <th>Jenis Kendaraan</th>
                            <th>Plat Nomor</th>
                            <th>Jam Masuk Parkir</th>
                            <th>Jam Keluar Parkir</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php $__currentLoopData = $approval; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($a->vehicle->user->username); ?></td>
                                <td><?php echo e($a->vehicle->vehicleType->name); ?></td>
                                <td><?php echo e($a->vehicle->licence_plate); ?></td>
                                <td><?php echo e($a->entry_time); ?></td>
                                <td><?php echo e($a->exit_time); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\final-Project_Kelompok-1\resources\views/admin/summary/index.blade.php ENDPATH**/ ?>