<?php $__env->startSection('content'); ?>

  <section class="book_section">
    <div class="form_container">
      <form action="" class="text-center">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-8">
              <?php if($approval->action === 'Entry' || $approval->action === 'Pending'): ?>
                <div class="detail_container">
                  <div class="detail-box text-dark text-start">
                    <h5>Nama Pengunjung: <?php echo e(Auth::user()->username); ?></h5><br>
                    <h5>Jenis Kendaraan: <?php echo e($vehicle->vehicleType->name); ?></h5><br>
                    <h5>Plat Nomor: <?php echo e($vehicle->licence_plate); ?></h5><br>
                    <h5>Lokasi Parkir: Lantai <?php echo e($block->floor_id); ?> | <?php echo e($block->block); ?></h5><br>
                    <h5>
                        Waktu Parkir: <?php if($approval->exit_time): ?>
                            <?php echo e(\Carbon\Carbon::parse($approval->exit_time)->diffForHumans($approval->entry_time)); ?>

                        <?php else: ?>
                            <?php echo e(\Carbon\Carbon::parse($approval->entry_time)->diffForHumans()); ?>

                        <?php endif; ?>
                    </h5><br>
                    <h5>Keterangan: <?php echo e($paymentStatus === 'Paid' ? 'Sudah Dibayar' : 'Belum Dibayar'); ?></h5><br>
                  </div>
                </div>
              <?php endif; ?>
              <p>Silahkan Bayar Terlebih Dahulu Sebelum Keluar Parkir</p>
                <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#exitModal">
                    Keluar Parkir
                </button>
            </div>
          </div>
        </div>
      </form>
    </div>
    <div class="img-box">
      <img src="<?php echo e(asset('pengunjung/images/book-car.png')); ?>" alt="">
    </div>
  </section>

<div class="modal fade" id="exitModal" tabindex="-1" aria-labelledby="exitModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exitModalLabel">Konfirmasi Keluar Parkir</h5>
      </div>
      <div class="modal-body">
        <p>Apakah Anda yakin ingin keluar dari tempat parkir?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        <form action="<?php echo e(url('/parkOut')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="vehicle_id" value="<?php echo e($vehicle->id); ?>">
          <button type="submit" class="btn btn-danger">Keluar Parkir</button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('pengunjung.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\final-Project_Kelompok-1\resources\views/pengunjung/parkir.blade.php ENDPATH**/ ?>