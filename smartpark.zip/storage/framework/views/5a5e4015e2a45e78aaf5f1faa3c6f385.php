
<?php $__env->startSection('content'); ?>
<div class="container text-center">
    <div class="row justify-content-around mb-3">
        <div class="col-4 col-lg-6 col-md-6">
            <div class="card card-stat">
                <div class="card-body px-4 py-4-5">
                    <h3 class="ps-2">Total Pegawai</h3>
                    <div class="d-flex align-items-start flex-column p-2 mb-2">
                        <p class="fs-1 p-3 rounded fw-bolder text-primary"><?php echo e($employees); ?></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-4 col-lg-6 col-md-6">
            <div class="card card-stat">
                <div class="card-body px-4 py-4-5">
                    <h3 class="ps-2">Total Pengunjung</h3>
                    <div class="d-flex align-items-start flex-column p-2 mb-2">
                        <p class="fs-1 p-3 rounded fw-bolder text-primary"><?php echo e($visitors); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Pemilik</th>
                        <th>Plat Nomor</th>
                        <th>Jenis Kendaraan</th>
                        <th>Lokasi</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>No</th>
                        <th>Nama Pemilik</th>
                        <th>Plat Nomor</th>
                        <th>Jenis Kendaraan</th>
                        <th>Lokasi</th>
                        <th>Action</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php $__currentLoopData = $parkingSession; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($ps->user->username); ?></td>
                            <td><?php echo e($ps->vehicle->licence_plate); ?></td>
                            <td><?php echo e($ps->vehicle->vehicleType->name); ?></td>
                            <td>Lantai: <?php echo e($ps->blocknumber->parkingfloor->floor_number); ?>, Block: <?php echo e($ps->blocknumber->block); ?></td>
                            <td>
                                <div class="btn-group me-2" role="group" aria-label="Basic mixed styles example">
                                    <a href="#" class="btn btn-sm btn-primary mr-2">Detail</a>
                                </div>
                                <div class="btn-group me-2" role="group" aria-label="Basic mixed styles example">
                                    <form onsubmit="return confirm('Apakah anda yakin ingin menerima permintaan?')" class="d-inline" action="<?php echo e(route('admin.parkingSession.accept', $ps->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                        <button type="submit" class="btn btn-sm btn-success mr-2">Terima</button>
                                    </form>
                                </div>
                                <div class="btn-group me-2" role="group" aria-label="Basic mixed styles example">
                                    <form onsubmit="return confirm('Apakah anda yakin ingin menolak permintaan?')" class="d-inline" action="<?php echo e(route('admin.parkingSession.decline', $ps->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger">Tolak</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
  <h5 class="modal-title" id="exampleModalLabel">Tambah Pegawai</h5>
</div>
<div class="modal-body">
    <form abframeid="iframe.0.621681743693705" abineguid="6CBCF04EEF434DF783A5C40E835D891D" action="/admin/daftar-staff/store" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group row">
            <label for="username" class="col-4 col-form-label">Nama</label> 
            <div class="col-8">
            <input id="username" name="username" type="text" class="form-control">
            </div>
        </div>
        <div class="form-group row">
            <label for="full_name" class="col-4 col-form-label">Full Name</label> 
            <div class="col-8">
            <input id="full_name" name="full_name" type="text" class="form-control">
            </div>
        </div>
        <div class="form-group row">
            <label for="role_id" class="col-4 col-form-label">Position</label> 
            <div class="col-8">
            <select id="role_id" name="role_id" class="custom-select">
                
            </select>
            </div>
        </div> 
        <div class="form-group row justify-content-center">
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </form>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\final-Project_Kelompok-1 - Copy\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>