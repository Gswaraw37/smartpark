<?php $__env->startSection('content'); ?>

<!-- book section -->
<section class="book_section">
  <div class="form_container">
      <?php if(auth()->user()->vehicle->isEmpty()): ?>
          <form action="" class="text-center">
              <p>Harap Tambahkan Data Kendaraan Terlebih Dahulu.</p>
              <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#vehicleModal">+ Tambah Kendaraan</button>
          </form>
      <?php else: ?>
          <?php if($approvalStatus === 'Pending'): ?>
          <div class="form_container">
            <form action="" class="text-center">
              <div class="container">
                <div class="row justify-content-center">
                  <div class="col-md-8">
                    <div class="detail_container">
                        <div class="detail-box text-dark text-start">
                            <h5>Nama Pengunjung: <?php echo e(Auth::user()->username); ?></h5><br>
                            <h5>Jenis Kendaraan: <?php echo e($vehicles->first()->vehicleType->name); ?></h5><br>
                            <h5>Plat Nomor: <?php echo e($vehicles->first()->licence_plate); ?></h5><br>
                            <h5>Lokasi Parkir: Lantai <?php echo e($blocknumber->floor_id); ?> | <?php echo e($blocknumber->block); ?></h5><br>
                            <h5>
                                Waktu Parkir: <?php if($approval->exit_time): ?>
                                    <?php echo e(\Carbon\Carbon::parse($approval->exit_time)->diffForHumans($approval->entry_time)); ?>

                                <?php else: ?>
                                    <?php echo e(\Carbon\Carbon::parse($approval->entry_time)->diffForHumans()); ?>

                                <?php endif; ?>
                            </h5><br>
                            <h5>Keterangan: <?php echo e($paymentStatus === 'Paid' ? 'Sudah Dibayar' : 'Belum Dibayar'); ?></h5><br>
                        </div>
                    </div>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-md-8">
                                <p>Sedang menunggu persetujuan...</p>
                            </div>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
          <?php elseif($approvalStatus === 'Rejected'): ?>
          <div class="form_container">
            <form action="" class="text-center">
              <div class="container">
                <div class="row justify-content-center">
                  <div class="col-md-8">
                    <div class="detail_container">
                        <div class="detail-box text-dark text-start">
                            <h5>Nama Pengunjung: <?php echo e(Auth::user()->username); ?></h5><br>
                            <h5>Jenis Kendaraan: <?php echo e($vehicles->first()->vehicleType->name); ?></h5><br>
                            <h5>Plat Nomor: <?php echo e($vehicles->first()->licence_plate); ?></h5><br>
                            <h5>Lokasi Parkir: Lantai <?php echo e($blocknumber->floor_id); ?> | <?php echo e($blocknumber->block); ?></h5><br>
                            <h5>
                                Waktu Parkir: <?php if($approval->exit_time): ?>
                                    <?php echo e(\Carbon\Carbon::parse($approval->exit_time)->diffForHumans($approval->entry_time)); ?>

                                <?php else: ?>
                                    <?php echo e(\Carbon\Carbon::parse($approval->entry_time)->diffForHumans()); ?>

                                <?php endif; ?>
                            </h5><br>
                            <h5>Keterangan: <?php echo e($paymentStatus === 'Paid' ? 'Sudah Dibayar' : 'Belum Dibayar'); ?></h5><br>
                        </div>
                    </div>
                    <p>Harap Selesaikan Pembayaran Terlebih Dahulu.</p>
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exitModal">
                        Bayar Parkir
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
          <?php else: ?>
              <div class="container">
                  <div class="row justify-content-center">
                      <div class="col-md-4 mb-4">
                          <div class="card">
                              <img src="https://dummyimage.com/600x400/000/fff&text=Parking" class="card-img-top" alt="...">
                              <div class="card-body text-center">
                                  <?php if($blocknumber): ?>
                                      <h3 class="card-title">Lantai <?php echo e($blocknumber->parkingfloor->floor_number); ?></h3>
                                      <h5 class="card-title"><?php echo e($blocknumber->block); ?></h5>
                                      <?php if($approval && $approval->action === 'Entry'): ?>
                                          <a href="<?php echo e(url('/parkir')); ?>" class="btn btn-primary">Kembali</a>
                                      <?php else: ?>
                                          <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#parkModal">Masuk Parkir</button>
                                      <?php endif; ?>
                                  <?php else: ?>
                                      <h3 class="card-title">Tidak ada blok tersedia</h3>
                                  <?php endif; ?>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          <?php endif; ?>
      <?php endif; ?>
  </div>
  <div class="img-box">
      <img src="<?php echo e(asset('pengunjung/images/book-car.png')); ?>" alt="">
  </div>
</section>
<!-- end book section -->

  <!-- Modal -->
  <div class="modal fade" id="vehicleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Tambah Kendaraan</h5>
        </div>
        <div class="modal-body">
            <form abframeid="iframe.0.621681743693705" abineguid="6CBCF04EEF434DF783A5C40E835D891D" action="/" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                    <label for="licence_plate" class="col-4 col-form-label">Plat Nomor</label> 
                    <div class="col-8">
                    <input id="licence_plate" name="licence_plate" type="text" class="form-control">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="vehicle_type_id" class="col-4 col-form-label">Tipe Kendaraan</label> 
                    <div class="col-8">
                      <?php $__currentLoopData = $vehicletype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php
                          $cek = (old('vehicle_type_id') == $vt->id) ? 'checked' : '';
                      ?>
                        <div class="custom-control custom-radio custom-control-inline">
                          <input name="vehicle_type_id" id="vehicle_type_id<?php echo e($vt->id); ?>" type="radio" class="custom-control-input" value="<?php echo e($vt->id); ?>" <?php echo e($cek); ?>> 
                          <label for="vehicle_type_id<?php echo e($vt->id); ?>" class="custom-control-label"><?php echo e($vt->name); ?></label>
                        </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                </div> 
                <div class="form-group row justify-content-center">
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </div>
                </div>
            </form>
        </div>
      </div>
    </div>
  </div>
  
  <div class="modal fade" id="parkModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Masuk Parkir</h5>
        </div>
        <div class="modal-body">
            <form abframeid="iframe.0.621681743693705" abineguid="6CBCF04EEF434DF783A5C40E835D891D" action="<?php echo e(url('/parkIn')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="block_id" value="<?php echo e($blocknumber->id); ?>">
                <div class="form-group row">
                    <label for="vehicle_id" class="col-4 col-form-label">Pilih Kendaraan</label> 
                    <div class="col-8">
                      <select id="vehicle_id" name="vehicle_id" class="custom-select" required>
                        <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($v->id); ?>"><?php echo e($v->vehicleType->name); ?> <?php echo e($v->licence_plate); ?></option> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                </div>
                <div class="form-group row justify-content-center">
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Parkir</button>
                    </div>
                </div>
            </form>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="exitModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Konfirmasi Keluar Parkir</h5>
            </div>
            <div class="modal-body">
                <p>Apakah Anda yakin ingin keluar dari tempat parkir?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <form action="<?php echo e(route('parkir.resubmit')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $veh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="hidden" name="vehicle_id" value="<?php echo e($veh->id); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <button type="submit" class="btn btn-primary">Bayar Parkir</button>
                </form>
            </div>
        </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('pengunjung.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\final-Project_Kelompok-1\resources\views/pengunjung/index.blade.php ENDPATH**/ ?>