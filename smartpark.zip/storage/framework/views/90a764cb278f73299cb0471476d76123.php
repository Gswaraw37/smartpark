
<?php $__env->startSection('content'); ?>

<section class="about_section layout_padding2-top layout_padding-bottom ">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-9 px-0">
          <div class="img-box">
            <img src="<?php echo e(asset('pengunjung/images/about-img.png')); ?>" alt="">
          </div>
        </div>
        <div class="col-md-4 col-lg-3">
          <div class="detail-box">
            <h2>
              About Vehicles
            </h2>
            <h5>
                <b>Nama Pemilik:</b> <?php echo e($parkingSession->user->username); ?>

            </h5>
            <h5>
                <b>Jenis Kendaraan:</b> <?php echo e($parkingSession->vehicle->vehicleType->name); ?>

            </h5>
            <h5>
                <b>Plat Nomor:</b> <?php echo e($parkingSession->vehicle->licence_plate); ?>

            </h5>
            <h5>
                <b>Lokasi Parkir:</b> Lantai <?php echo e($parkingSession->blocknumber->parkingfloor->floor_number); ?> | <?php echo e($parkingSession->blocknumber->block); ?> 
            </h5>
            <h5>
                <b>Jam Masuk Parkir:</b> <?php echo e(\Carbon\Carbon::parse($approval->entry_time)->format('H:i:s')); ?> | <?php echo e(\Carbon\Carbon::parse($approval->entry_time)->diffForHumans()); ?>

            </h5>
            <h5>
                <?php
                    $paymentStatus = $parkingSession->payment ? $parkingSession->payment->payment_status : 'Belum Dibayar';
                ?>
                <b>Status Pembayaran:</b> <?php echo e($paymentStatus === 'Paid' ? 'Sudah Dibayar' : 'Belum Dibayar'); ?>

            </h5>
          </div>
        </div>
      </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\final-Project_Kelompok-1\resources\views/admin/detail/kendaraan.blade.php ENDPATH**/ ?>