<!-- slider section -->
<section class=" slider_section position-relative">
    <div class="slider_container">
      <div class="img-box">
        <img src="<?php echo e(asset('pengunjung/images/hero-img.jpg')); ?>" alt="">
      </div>

      <?php if(session('messages')): ?>
      <div class="alert alert-info">
          Anda memiliki notifikasi baru:
          <ul>
              <?php $__currentLoopData = session('messages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($message); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
      </div>
      <?php endif; ?>

        <div class="detail_container">
          <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
              <div class="carousel-item active">
                <div class="detail-box">
                  <h1>
                    Selamat Datang <br>
                    Di <br>
                    SmartPark
                  </h1>
                </div>
              </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
              <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
              <span class="sr-only">Next</span>
            </a>
          </div>
        </div>
    </div>
  </section>
  <!-- end slider section -->
</div><?php /**PATH C:\xampp\htdocs\final-Project_Kelompok-1\resources\views/pengunjung/layouts/slider.blade.php ENDPATH**/ ?>