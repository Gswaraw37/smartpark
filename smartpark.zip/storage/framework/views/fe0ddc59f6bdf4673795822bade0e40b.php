<?php $__env->startSection('content'); ?>

<section class="book_section">
    <div class="form_container">
        <div class="container">
            <div class="row justify-content-center">
                <?php $__currentLoopData = $blocknumber; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="https://dummyimage.com/600x400/000/fff&text=Parking" class="card-img-top" alt="...">
                            <div class="card-body text-center">
                                <h3 class="card-title">Lantai <?php echo e($bn->parkingfloor->floor_number); ?></h3>
                                <h5 class="card-title"><?php echo e($bn->block); ?></h5>
                                <?php if($bn->is_occupied): ?>
                                    <button type="button" class="btn btn-secondary" disabled>Tidak Tersedia</button>
                                <?php else: ?>
                                    <button type="button" class="btn btn-primary">Tersedia</button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-12">
                    <?php echo e($blocknumber->links()); ?> <!-- Pagination links -->
                </div>
            </div>
        </div>
    </div>
    <div class="img-box">
      <img src="<?php echo e(asset('pengunjung/images/book-car.png')); ?>" alt="">
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('pengunjung.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\final-Project_Kelompok-1\resources\views/pengunjung/lokasi/index.blade.php ENDPATH**/ ?>