<?php echo $__env->make('auth.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">

<?php echo $__env->yieldContent('content'); ?>

</div>

<?php echo $__env->make('auth.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\final-Project_Kelompok-1 - Copy\resources\views/auth/layouts/app.blade.php ENDPATH**/ ?>