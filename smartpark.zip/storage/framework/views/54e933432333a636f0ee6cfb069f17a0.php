<div class="modal" id="confirmHapusModal">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body modal-bg1 text-center">
                <h5>Anda Yakin Ingin Menghapus Data Staff ini?</h5>
            </div>
            <div class="modalFooter text-center modal-bg1">
                <div class="mb-3">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="submit" class="btn btn-danger">Hapus</button>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\final-Project_Kelompok-1\resources\views/admin/daftar/staff/modal/popup.blade.php ENDPATH**/ ?>