<?php $__env->startSection('content'); ?>

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Kendaraan</h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="row justify-content-between">
                <div class="col-8">
                    <h6 class="m-0 font-weight-bold text-primary">Daftar Motor</h6>
                </div>
                </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Pemilik</th>
                            <th>Plat Nomor</th>
                            <th>Jenis Kendaraan</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Nama Pemilik</th>
                            <th>Plat Nomor</th>
                            <th>Jenis Kendaraan</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php
                            $no = 1;
                        ?>
                        <?php $__currentLoopData = $vehicle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($v->vehicleType->name == 'Motor'): ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($v->user->username); ?></td>
                                    <td><?php echo e($v->licence_plate); ?></td>
                                    <td><?php echo e($v->vehicleType->name); ?></td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\final-Project_Kelompok-1\resources\views/admin/daftar/kendaraan/motor.blade.php ENDPATH**/ ?>